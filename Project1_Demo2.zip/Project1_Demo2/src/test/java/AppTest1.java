import org.example.App1;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AppTest1 {

    @Test
    void testAdd() {
        App1 app = new App1();

        int result = app.add(20, 20);
        int result2 =app.sub(50,20);

        assertEquals(40, result);
        assertEquals(30, result2);
    }
}